/***************************************************************************//**
* \file ROSSerial_UART_BOOT.h
* \version 4.0
*
* \brief
*  This file provides constants and parameter values of the bootloader
*  communication APIs for the SCB Component.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2014-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_BOOT_ROSSerial_UART_H)
#define CY_SCB_BOOT_ROSSerial_UART_H

#include "ROSSerial_UART_PVT.h"

#if (ROSSerial_UART_SCB_MODE_I2C_INC)
    #include "ROSSerial_UART_I2C.h"
#endif /* (ROSSerial_UART_SCB_MODE_I2C_INC) */

#if (ROSSerial_UART_SCB_MODE_EZI2C_INC)
    #include "ROSSerial_UART_EZI2C.h"
#endif /* (ROSSerial_UART_SCB_MODE_EZI2C_INC) */

#if (ROSSerial_UART_SCB_MODE_SPI_INC || ROSSerial_UART_SCB_MODE_UART_INC)
    #include "ROSSerial_UART_SPI_UART.h"
#endif /* (ROSSerial_UART_SCB_MODE_SPI_INC || ROSSerial_UART_SCB_MODE_UART_INC) */


/***************************************
*  Conditional Compilation Parameters
****************************************/

/* Bootloader communication interface enable */
#define ROSSerial_UART_BTLDR_COMM_ENABLED ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_ROSSerial_UART) || \
                                             (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))

/* Enable I2C bootloader communication */
#if (ROSSerial_UART_SCB_MODE_I2C_INC)
    #define ROSSerial_UART_I2C_BTLDR_COMM_ENABLED     (ROSSerial_UART_BTLDR_COMM_ENABLED && \
                                                            (ROSSerial_UART_SCB_MODE_UNCONFIG_CONST_CFG || \
                                                             ROSSerial_UART_I2C_SLAVE_CONST))
#else
     #define ROSSerial_UART_I2C_BTLDR_COMM_ENABLED    (0u)
#endif /* (ROSSerial_UART_SCB_MODE_I2C_INC) */

/* EZI2C does not support bootloader communication. Provide empty APIs */
#if (ROSSerial_UART_SCB_MODE_EZI2C_INC)
    #define ROSSerial_UART_EZI2C_BTLDR_COMM_ENABLED   (ROSSerial_UART_BTLDR_COMM_ENABLED && \
                                                         ROSSerial_UART_SCB_MODE_UNCONFIG_CONST_CFG)
#else
    #define ROSSerial_UART_EZI2C_BTLDR_COMM_ENABLED   (0u)
#endif /* (ROSSerial_UART_EZI2C_BTLDR_COMM_ENABLED) */

/* Enable SPI bootloader communication */
#if (ROSSerial_UART_SCB_MODE_SPI_INC)
    #define ROSSerial_UART_SPI_BTLDR_COMM_ENABLED     (ROSSerial_UART_BTLDR_COMM_ENABLED && \
                                                            (ROSSerial_UART_SCB_MODE_UNCONFIG_CONST_CFG || \
                                                             ROSSerial_UART_SPI_SLAVE_CONST))
#else
        #define ROSSerial_UART_SPI_BTLDR_COMM_ENABLED (0u)
#endif /* (ROSSerial_UART_SPI_BTLDR_COMM_ENABLED) */

/* Enable UART bootloader communication */
#if (ROSSerial_UART_SCB_MODE_UART_INC)
       #define ROSSerial_UART_UART_BTLDR_COMM_ENABLED    (ROSSerial_UART_BTLDR_COMM_ENABLED && \
                                                            (ROSSerial_UART_SCB_MODE_UNCONFIG_CONST_CFG || \
                                                             (ROSSerial_UART_UART_RX_DIRECTION && \
                                                              ROSSerial_UART_UART_TX_DIRECTION)))
#else
     #define ROSSerial_UART_UART_BTLDR_COMM_ENABLED   (0u)
#endif /* (ROSSerial_UART_UART_BTLDR_COMM_ENABLED) */

/* Enable bootloader communication */
#define ROSSerial_UART_BTLDR_COMM_MODE_ENABLED    (ROSSerial_UART_I2C_BTLDR_COMM_ENABLED   || \
                                                     ROSSerial_UART_SPI_BTLDR_COMM_ENABLED   || \
                                                     ROSSerial_UART_EZI2C_BTLDR_COMM_ENABLED || \
                                                     ROSSerial_UART_UART_BTLDR_COMM_ENABLED)


/***************************************
*        Function Prototypes
***************************************/

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (ROSSerial_UART_I2C_BTLDR_COMM_ENABLED)
    /* I2C Bootloader physical layer functions */
    void ROSSerial_UART_I2CCyBtldrCommStart(void);
    void ROSSerial_UART_I2CCyBtldrCommStop (void);
    void ROSSerial_UART_I2CCyBtldrCommReset(void);
    cystatus ROSSerial_UART_I2CCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus ROSSerial_UART_I2CCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

    /* Map I2C specific bootloader communication APIs to SCB specific APIs */
    #if (ROSSerial_UART_SCB_MODE_I2C_CONST_CFG)
        #define ROSSerial_UART_CyBtldrCommStart   ROSSerial_UART_I2CCyBtldrCommStart
        #define ROSSerial_UART_CyBtldrCommStop    ROSSerial_UART_I2CCyBtldrCommStop
        #define ROSSerial_UART_CyBtldrCommReset   ROSSerial_UART_I2CCyBtldrCommReset
        #define ROSSerial_UART_CyBtldrCommRead    ROSSerial_UART_I2CCyBtldrCommRead
        #define ROSSerial_UART_CyBtldrCommWrite   ROSSerial_UART_I2CCyBtldrCommWrite
    #endif /* (ROSSerial_UART_SCB_MODE_I2C_CONST_CFG) */

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (ROSSerial_UART_I2C_BTLDR_COMM_ENABLED) */


#if defined(CYDEV_BOOTLOADER_IO_COMP) && (ROSSerial_UART_EZI2C_BTLDR_COMM_ENABLED)
    /* Bootloader physical layer functions */
    void ROSSerial_UART_EzI2CCyBtldrCommStart(void);
    void ROSSerial_UART_EzI2CCyBtldrCommStop (void);
    void ROSSerial_UART_EzI2CCyBtldrCommReset(void);
    cystatus ROSSerial_UART_EzI2CCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus ROSSerial_UART_EzI2CCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

    /* Map EZI2C specific bootloader communication APIs to SCB specific APIs */
    #if (ROSSerial_UART_SCB_MODE_EZI2C_CONST_CFG)
        #define ROSSerial_UART_CyBtldrCommStart   ROSSerial_UART_EzI2CCyBtldrCommStart
        #define ROSSerial_UART_CyBtldrCommStop    ROSSerial_UART_EzI2CCyBtldrCommStop
        #define ROSSerial_UART_CyBtldrCommReset   ROSSerial_UART_EzI2CCyBtldrCommReset
        #define ROSSerial_UART_CyBtldrCommRead    ROSSerial_UART_EzI2CCyBtldrCommRead
        #define ROSSerial_UART_CyBtldrCommWrite   ROSSerial_UART_EzI2CCyBtldrCommWrite
    #endif /* (ROSSerial_UART_SCB_MODE_EZI2C_CONST_CFG) */

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (ROSSerial_UART_EZI2C_BTLDR_COMM_ENABLED) */

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (ROSSerial_UART_SPI_BTLDR_COMM_ENABLED)
    /* SPI Bootloader physical layer functions */
    void ROSSerial_UART_SpiCyBtldrCommStart(void);
    void ROSSerial_UART_SpiCyBtldrCommStop (void);
    void ROSSerial_UART_SpiCyBtldrCommReset(void);
    cystatus ROSSerial_UART_SpiCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus ROSSerial_UART_SpiCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

    /* Map SPI specific bootloader communication APIs to SCB specific APIs */
    #if (ROSSerial_UART_SCB_MODE_SPI_CONST_CFG)
        #define ROSSerial_UART_CyBtldrCommStart   ROSSerial_UART_SpiCyBtldrCommStart
        #define ROSSerial_UART_CyBtldrCommStop    ROSSerial_UART_SpiCyBtldrCommStop
        #define ROSSerial_UART_CyBtldrCommReset   ROSSerial_UART_SpiCyBtldrCommReset
        #define ROSSerial_UART_CyBtldrCommRead    ROSSerial_UART_SpiCyBtldrCommRead
        #define ROSSerial_UART_CyBtldrCommWrite   ROSSerial_UART_SpiCyBtldrCommWrite
    #endif /* (ROSSerial_UART_SCB_MODE_SPI_CONST_CFG) */

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (ROSSerial_UART_SPI_BTLDR_COMM_ENABLED) */

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (ROSSerial_UART_UART_BTLDR_COMM_ENABLED)
    /* UART Bootloader physical layer functions */
    void ROSSerial_UART_UartCyBtldrCommStart(void);
    void ROSSerial_UART_UartCyBtldrCommStop (void);
    void ROSSerial_UART_UartCyBtldrCommReset(void);
    cystatus ROSSerial_UART_UartCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus ROSSerial_UART_UartCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

    /* Map UART specific bootloader communication APIs to SCB specific APIs */
    #if (ROSSerial_UART_SCB_MODE_UART_CONST_CFG)
        #define ROSSerial_UART_CyBtldrCommStart   ROSSerial_UART_UartCyBtldrCommStart
        #define ROSSerial_UART_CyBtldrCommStop    ROSSerial_UART_UartCyBtldrCommStop
        #define ROSSerial_UART_CyBtldrCommReset   ROSSerial_UART_UartCyBtldrCommReset
        #define ROSSerial_UART_CyBtldrCommRead    ROSSerial_UART_UartCyBtldrCommRead
        #define ROSSerial_UART_CyBtldrCommWrite   ROSSerial_UART_UartCyBtldrCommWrite
    #endif /* (ROSSerial_UART_SCB_MODE_UART_CONST_CFG) */

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (ROSSerial_UART_UART_BTLDR_COMM_ENABLED) */

/**
* \addtogroup group_bootloader
* @{
*/

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (ROSSerial_UART_BTLDR_COMM_ENABLED)
    #if (ROSSerial_UART_SCB_MODE_UNCONFIG_CONST_CFG)
        /* Bootloader physical layer functions */
        void ROSSerial_UART_CyBtldrCommStart(void);
        void ROSSerial_UART_CyBtldrCommStop (void);
        void ROSSerial_UART_CyBtldrCommReset(void);
        cystatus ROSSerial_UART_CyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
        cystatus ROSSerial_UART_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    #endif /* (ROSSerial_UART_SCB_MODE_UNCONFIG_CONST_CFG) */

    /* Map SCB specific bootloader communication APIs to common APIs */
    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_ROSSerial_UART)
        #define CyBtldrCommStart    ROSSerial_UART_CyBtldrCommStart
        #define CyBtldrCommStop     ROSSerial_UART_CyBtldrCommStop
        #define CyBtldrCommReset    ROSSerial_UART_CyBtldrCommReset
        #define CyBtldrCommWrite    ROSSerial_UART_CyBtldrCommWrite
        #define CyBtldrCommRead     ROSSerial_UART_CyBtldrCommRead
    #endif /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_ROSSerial_UART) */

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (ROSSerial_UART_BTLDR_COMM_ENABLED) */

/** @} group_bootloader */

/***************************************
*           API Constants
***************************************/

/* Timeout unit in milliseconds */
#define ROSSerial_UART_WAIT_1_MS  (1u)

/* Return number of bytes to copy into bootloader buffer */
#define ROSSerial_UART_BYTES_TO_COPY(actBufSize, bufSize) \
                            ( ((uint32)(actBufSize) < (uint32)(bufSize)) ? \
                                ((uint32) (actBufSize)) : ((uint32) (bufSize)) )

/* Size of Read/Write buffers for I2C bootloader  */
#define ROSSerial_UART_I2C_BTLDR_SIZEOF_READ_BUFFER   (64u)
#define ROSSerial_UART_I2C_BTLDR_SIZEOF_WRITE_BUFFER  (64u)

/* Byte to byte time interval: calculated basing on current component
* data rate configuration, can be defined in project if required.
*/
#ifndef ROSSerial_UART_SPI_BYTE_TO_BYTE
    #define ROSSerial_UART_SPI_BYTE_TO_BYTE   (160u)
#endif

/* Byte to byte time interval: calculated basing on current component
* baud rate configuration, can be defined in the project if required.
*/
#ifndef ROSSerial_UART_UART_BYTE_TO_BYTE
    #define ROSSerial_UART_UART_BYTE_TO_BYTE  (174u)
#endif /* ROSSerial_UART_UART_BYTE_TO_BYTE */

#endif /* (CY_SCB_BOOT_ROSSerial_UART_H) */


/* [] END OF FILE */
