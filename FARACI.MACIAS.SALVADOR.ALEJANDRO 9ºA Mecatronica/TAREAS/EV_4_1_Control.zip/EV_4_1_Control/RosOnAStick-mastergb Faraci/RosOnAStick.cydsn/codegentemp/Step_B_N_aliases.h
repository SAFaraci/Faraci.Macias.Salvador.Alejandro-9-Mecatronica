/*******************************************************************************
* File Name: Step_B_N.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Step_B_N_ALIASES_H) /* Pins Step_B_N_ALIASES_H */
#define CY_PINS_Step_B_N_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define Step_B_N_0			(Step_B_N__0__PC)
#define Step_B_N_0_PS		(Step_B_N__0__PS)
#define Step_B_N_0_PC		(Step_B_N__0__PC)
#define Step_B_N_0_DR		(Step_B_N__0__DR)
#define Step_B_N_0_SHIFT	(Step_B_N__0__SHIFT)
#define Step_B_N_0_INTR	((uint16)((uint16)0x0003u << (Step_B_N__0__SHIFT*2u)))

#define Step_B_N_INTR_ALL	 ((uint16)(Step_B_N_0_INTR))


#endif /* End Pins Step_B_N_ALIASES_H */


/* [] END OF FILE */
